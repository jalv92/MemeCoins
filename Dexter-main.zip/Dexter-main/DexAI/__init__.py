from .colors import cc, ColorCodes

__all__ = ["cc", "ColorCodes"]